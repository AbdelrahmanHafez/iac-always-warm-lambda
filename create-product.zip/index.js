exports.handler =  async function handler (event)  {
  // TODO implement
  const response = {
      statusCode: 200,
      body: JSON.stringify('Hello Darkness my old friend!'),
  };
  return response;
};
